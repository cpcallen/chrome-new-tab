chrome.tabs.update({
    url:'chrome-internal://newtab/'
});
